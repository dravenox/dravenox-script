export default async function handler(req, res) {
  const token = process.env.DISCORD_TOKEN;
  const channelId = process.env.DISCORD_CHANNEL_ID;
  const statusAuthor = process.env.STATUS_AUTHOR;

  try {
    const response = await fetch(`https://discord.com/api/v9/channels/${channelId}/messages?limit=50`, {
      headers: {
        Authorization: token,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      return res.status(500).json({ error: `Discord API error: ${response.status}` });
    }

    const messages = await response.json();
    const statusMsg = messages.find(
      m => m.embeds?.length > 0 && m.author?.username === statusAuthor
    );

    if (!statusMsg) {
      return res.status(404).json({ error: 'Status message not found' });
    }

    const embed = statusMsg.embeds[0];
    const statusField = embed.fields?.find(f =>
      f.name.toLowerCase().includes('server status')
    );
    const serverStatus = statusField?.value || 'Unknown';
    const isServerUp = serverStatus.toLowerCase().includes('online') || serverStatus.toLowerCase().includes('up');

    let playerCount = 0;
    const playerField = embed.fields?.find(f =>
      f.name.toLowerCase().includes('players online') ||
      f.name.toLowerCase().includes('online count')
    );
    if (playerField) {
      const match = playerField.value.match(/\d+/);
      if (match) playerCount = parseInt(match[0]);
    }

    res.json({
      online_user_gtfy: playerCount.toString(),
      server_status: isServerUp ? 'active' : 'inactive'
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Unexpected error occurred.' });
  }
}
